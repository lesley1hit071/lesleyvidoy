CREATE TABLE IF NOT EXISTS `domains` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(191) NOT NULL,
  `url` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `domains` (`name`, `url`, `is_active`, `created_at`)
VALUES 
  ('cdn.videycz.my.id', 'http://cdn.videycz.my.id', 1, NOW()),
  ('cdn.videyyx.com', 'http://cdn.videyyx.com', 1, NOW());
